{{-- <script src="{{ asset('js/bootstrap.min.js') }}"></script> --}}
{{-- <script src="{{ asset('js/jquery.min.js') }}"></script> --}}

<script src="{{ asset('js/nav.js') }}"></script>
<script src="{{ asset('js/testimonial.js') }}"></script>
<script src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script src="{{ asset('js/jqzoomer.1.0.js')}}"></script>