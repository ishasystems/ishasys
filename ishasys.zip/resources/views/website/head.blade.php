<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
 
    <link rel="shortcut icon" href="{{ asset('image/logo.ico') }}" type="image/x-icon">
     <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}"> 
    <link rel="stylesheet" href="{{ asset('css/nav.css') }}">
    <link rel="stylesheet" href="{{ asset('css/global.css?v=1.2') }}">


<!------ Include the above in your HEAD tag ---------->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css">
<script src="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.js"></script>
<link rel="stylesheet" href="{{ asset('css/slider.css') }}">
<script src="{{ asset('js/slider.js') }}"></script>
<link rel="stylesheet" href="{{ asset('css/home_about.css') }}">
<link rel="stylesheet" href="{{ asset('css/home_service.css') }}">
<link rel="stylesheet" href="{{ asset('css/testimonial.css') }}">
<link rel="stylesheet" href="{{asset('css/contact.css')}}">
<link rel="stylesheet" href="{{ asset('css/product.css') }}">
<link rel="stylesheet" href="{{ asset('css/single.css') }}">
<link href="http://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
<link href="http://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
{{-- <script src="http://code.jquery.com/jquery-1.11.3.min.js"></script> --}}
{{-- <script src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script> --}}




<!-- slider lib end  -->
{{-- end home page lib --}}
    
    <title>{{ env('APP_NAME')}}</title>