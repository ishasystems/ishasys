<div class="parallax">
    <div class="" style="vertical-align: middle;text-align:center;bottom:50px">
    <a href="#" class="btn btn-success btn-lg" style="bottom:200px !important" >Request Quote</a>
    </div>
</div>



<style>
.wrapper {
    text-align: center;
}

.button {
    position: absolute;
    top: 50%;
}
.parallax {
  /* The image used */
  background-image: url({{ asset('image/slider/1.jpeg') }});

  /* Set a specific height */
  min-height: 200px; 

  /* Create the parallax scrolling effect */
  background-attachment: fixed;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
</style>