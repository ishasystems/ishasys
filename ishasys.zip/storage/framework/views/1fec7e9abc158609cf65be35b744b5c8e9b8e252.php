


<script src="<?php echo e(asset('js/nav.js')); ?>"></script>
<script src="<?php echo e(asset('js/testimonial.js')); ?>"></script>
<script src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo e(asset('js/jqzoomer.1.0.js')); ?>"></script>