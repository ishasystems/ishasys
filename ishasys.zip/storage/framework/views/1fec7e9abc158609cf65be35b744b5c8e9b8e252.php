<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/nav.js')); ?>"></script>
<script src="<?php echo e(asset('js/testimonial.js')); ?>"></script>