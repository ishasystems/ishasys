<?php echo $__env->make('website.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<section class="wrapper">
    <div class="container-fostrap">
      
        <div class="content">
            <div class="container">
                <div class="row">
					<?php if(count($products)>0): ?>
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-3">
							<div class="card">
								<a class="img-card" href="#">
								<img src='<?php echo e(asset("products/$product->product_img")); ?>' />
							    </a>
								<div class="card-content">
									<h4 class="card-title">
									<a href="#"><?php echo e($product->product_name); ?></a>
									</h4>
							
								</div>
								<div class="card-read-more">
								<a href="<?php echo e(route('product.single',$product->id)); ?>" class="btn btn-link btn-block">
										Read More
									</a>
								</div>
							</div>
						</div>	
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
						<h2>No Products Found Related to serach</h2>
					<?php endif; ?>
                    
				
         
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
