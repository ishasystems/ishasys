<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('website.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>
<!-- nav start here -->
<nav id="navbar" class="push better-nav fixed-top">
  <div class="container">
    <div class="head">
    <a href="<?php echo e(route('home-page')); ?>" class="brand">
        <div class="logo">
          <img class="image" src="<?php echo e(asset('image/logo.png')); ?>" data2x="https://66.media.tumblr.com/avatar_2dcdc7cf5b47_128.png" alt="Ishasystems & software" />
        </div>
        
      </a>
    </div>
    <div class="body">
      <ul>
      <li class="home active"><a href="<?php echo e(route('home-page')); ?>">Home</a></li>
        <li class="page"><a href="<?php echo e(route('about')); ?>">About</a></li>
        <li class="page"><a href="<?php echo e(route('services')); ?>">Services</a></li>

        <li class="blog dropdown"><a href="#">Products</a>
          
          <ul style="background: #fff;">
            <?php
                $products= productMenu();
            ?>
            <?php if(count($products)>0): ?>
              <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><a href="<?php echo e(route('product',$item->id)); ?>" style="color:#000 !important;"><?php echo e($item->category_name); ?></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            <?php endif; ?>
            

            

          </ul>
        </li>
        <li class="page"><a href="<?php echo e(route('portfolio')); ?>">Portfolio</a></li>

        <li class="page"><a href="<?php echo e(route('contact')); ?>">Contacts</a></li>
        <!-- <li class="more dropdown"><a href="#"><i class="fa fa-ellipsis-v" aria-hidden="true"></i></a>
          <span class="selector"></span>
          <ul>
            <li><a href="#">RSS</a></li>
            <li class="search clearfix">
              <form>
                <input type="text" placeholder="Search" />
                <button><i class="fa fa-search" aria-hidden="true"></i></button>
              </form>
            </li>
          </ul>
        </li> -->
      </ul>
    </div>
    <div class="toggle">
      <a href="#navbar-slide">
        <i class="fa fa-bars" aria-hidden="true"></i>
      </a>
    </div>
  </div>
</nav>

<!-- nav end here  -->
    
