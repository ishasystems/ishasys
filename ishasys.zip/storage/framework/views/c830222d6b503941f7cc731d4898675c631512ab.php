<?php echo $__env->make('admin.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;

<div class="container">
    <div class="row">

        <div class="col-xs-8 col-sm-12 col-md-8 col-lg-8">
            <?php if($errors->any()): ?>
              <h4><?php echo e($errors->first()); ?></h4>
             <?php endif; ?>

        <form action="<?php echo e(route('product.post')); ?>" method="POST" role="form" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>   
            <legend>Add Product</legend>

                <div class="form-group">
                    <label for="">product name</label>
                    <input type="text" name="product_name" class="form-control" id="" placeholder="Product Name">
                </div>
                <div class="form-group">
                    <label for="">Product Category</label>
                    <select name="category_id" class="form-control">
                        <?php if(count($category) >0): ?>
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->category_name); ?></option>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="product">Highlight feature</label>
                    <textarea name="product_description" id="editor" cols="30" rows="10" class="editor form-control"></textarea>
                </div>
                <div class="form-group">
                    <label for="">Technical Specification (Enter data in table)</label>
                    <textarea name="technical_spec" id="editor1" class="editor form-control" cols="30" rows="10"></textarea>
                </div>
                <div class="form-group">
                    <label for="">Catalogue</label>
                    <input type="file" name="catalogue" class="form-control">
                </div>
                <div class="form-group">
                    <label for="">Product Image</label>
                    <input type="file" name="image" class="form-control">
                </div>



                <button type="submit" class="btn btn-primary">Add </button>
            </form>

        </div>

    </div>
</div>


<script>
    CKEDITOR.replace( 'editor' );
    CKEDITOR.replace( 'editor1' );

</script>