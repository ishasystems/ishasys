<div class="aboutus-section" >
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12" style="padding:10px">
                <div class="aboutus">
                    <h2 class="aboutus-title">About Us</h2>
                    <p style="text-align:justify">It gives us pleasure to introduce ourselves as one of the leading service
                        Provider for Time & Attendance Solutions, Door Access Control , Security solutions
                        Gate Automation like Tripod Turnstiles , Flap Barriers etc. , Door Frame Metal
                        Detector & Baggage Scanners X-Ray machines & Boom Barrier for Vehicle Parking
                        for use in various types of industries such as Manufacturing industries, textile
                        industries, Chemical and pharmaceutical , Hotel , School & Colleges and Govermental
                        orgnizations etc.</p>
                    
                    
                    <a class="aboutus-more" href="<?php echo e(route('about')); ?>">read more</a>
                </div>
            </div>
       
            <div class="col-md-6 col-sm-6 col-xs-12" style="padding:10px">
                <div class="feature">
                <img src="<?php echo e(asset('image/img/h_1.jpeg')); ?>" alt="" class="img-circle" width="70%">
                </div>
            </div>
        </div>
    </div>
</div>


 