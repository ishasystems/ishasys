<header>
        <div class="owl-carousel owl-theme">
            <div class="item">
                <img src="<?php echo e(asset('image/slider/1.jpg')); ?>" alt="images not found">
               
                
                <div class="cover">
                    <div class="container">
                        <div class="header-content">
                            <div class="line"></div>
                            
                            <h1>CCTV & SURVILLANCE</h1>
                            
                        </div>
                    </div>
                 </div>
            </div>
            <div class="item">
                
                <img src="<?php echo e(asset('image/slider/2.jpeg')); ?>" alt="images not found">
                <div class="cover">
                    <div class="container">
                        <div class="header-content">
                            <div class="line animated bounceInLeft"></div>
                            <h1>BEST BIOMETRICS & ACCESS CONTROL SYSTEM</h1>
                            
                            
                        </div>
                    </div>
                 </div>
            </div>
            <div class="item">
                <img src="<?php echo e(asset('image/slider/3.jpeg')); ?>" alt="images not found">
               
                
                <div class="cover">
                    <div class="container">
                        <div class="header-content">
                            <div class="line animated bounceInLeft"></div>
                            
                            <h1>ERP & ATTENDANCE SOFTWARE</h1>
                            
                        </div>
                    </div>
                 </div>
            </div>
            <div class="item">
                <img src="<?php echo e(asset('image/slider/4.jpeg')); ?>" alt="images not found">
               
                
                <div class="cover">
                    <div class="container">
                        <div class="header-content">
                            <div class="line animated bounceInLeft"></div>
                            
                            <h1>GATE AUTOMATION & SOLUTION</h1>
                            
                        </div>
                    </div>
                 </div>
            </div>
        </div>
    </header>

    <script>
        $('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    dots:false,
    nav:true,
    mouseDrag:false,
    autoplay:true,
    animateOut: 'slideOutUp',
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
});
    </script>