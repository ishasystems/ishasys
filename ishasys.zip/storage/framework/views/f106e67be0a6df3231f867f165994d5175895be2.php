<?php echo $__env->make('admin.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="container">

    <div class="row">

    <a type="button" href="<?php echo e(route('product.add-form')); ?>" class="btn btn-primary">Add Product</a>

    </div>
    <div class="row">

        <div class="panel panel-default">
            <!-- Default panel contents -->
            <div class="panel-heading">Panel heading</div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>product</th>
                                <th>category</th>
                                <th>image</th>
                                <th>description</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($products)>0): ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($product->product_name); ?></td>
                                        <td><?php echo e($product->product_category[0]->category_name); ?></td>
                                        <td><img src='<?php echo e(asset("products/$product->product_img")); ?>' alt="" class="img-responsive" width="100" height="100"></td>
                                        <td><?php echo $product->product_description; ?></td>
                                        <td><a href="<?php echo e(route('product.edit-form', $product->id)); ?>"><i class="fa fa-pencil"></i></a>&nbsp;&nbsp; <a href="<?php echo e(route('product.delete',$product->id)); ?>" style="color:red"><i class="fa fa-trash-o"></i></a></td>

                                        </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

    </div>

</div>
