<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
 
    <link rel="shortcut icon" href="<?php echo e(asset('image/logo.ico')); ?>" type="image/x-icon">
     <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>"> 
    <link rel="stylesheet" href="<?php echo e(asset('css/nav.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/global.css')); ?>">
    

    <!-- slider lib -->

<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css">
<script src="//cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.js"></script>
<link rel="stylesheet" href="<?php echo e(asset('css/slider.css')); ?>">
<script src="<?php echo e(asset('js/slider.js')); ?>"></script>
<link rel="stylesheet" href="<?php echo e(asset('css/home_about.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/home_service.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/testimonial.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/contact.css')); ?>">


<!-- slider lib end  -->

    
    <title><?php echo e(env('APP_NAME')); ?></title>